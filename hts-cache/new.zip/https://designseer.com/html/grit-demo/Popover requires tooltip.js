<!DOCTYPE html>
<html lang="en-US" prefix="og: https://ogp.me/ns#">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	
<!-- Search Engine Optimization by Rank Math - https://s.rankmath.com/home -->
<title>Page Not Found - DesignSeer</title>
<meta name="robots" content="follow, noindex"/>
<meta property="og:locale" content="en_US">
<meta property="og:type" content="article">
<meta property="og:title" content="Page Not Found - DesignSeer">
<meta property="og:site_name" content="DesignSeer">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Page Not Found - DesignSeer">
<script type="application/ld+json" class="rank-math-schema">{"@context":"https://schema.org","@graph":[{"@type":"Person","@id":"https://designseer.com/#person","name":"Rijo Abraham","image":{"@type":"ImageObject","url":"https://designseer.com/wp-content/uploads/logo-new.png"}},{"@type":"WebSite","@id":"https://designseer.com/#website","url":"https://designseer.com","name":"Rijo Abraham","publisher":{"@id":"https://designseer.com/#person"},"inLanguage":"en-US"},{"@type":"BreadcrumbList","@id":"#breadcrumb","itemListElement":[{"@type":"ListItem","position":"1","item":{"@id":"https://designseer.com","name":"Home"}}]},{"@type":"WebPage","@id":"#webpage","url":"","name":"Page Not Found - DesignSeer","isPartOf":{"@id":"https://designseer.com/#website"},"inLanguage":"en-US","breadcrumb":{"@id":"#breadcrumb"}}]}</script>
<!-- /Rank Math WordPress SEO plugin -->

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="DesignSeer &raquo; Feed" href="https://designseer.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="DesignSeer &raquo; Comments Feed" href="https://designseer.com/comments/feed/" />
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/designseer.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.6.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='generate-fonts-css'  href='//fonts.googleapis.com/css?family=Pontano+Sans:regular' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://designseer.com/wp-includes/css/dist/block-library/style.min.css?ver=5.6.2' media='all' />
<link rel='stylesheet' id='button-plugin-css'  href='https://designseer.com/wp-content/plugins/btn-shortcode/css/style.css?ver=5.6.2' media='all' />
<link rel='stylesheet' id='generate-style-css'  href='https://designseer.com/wp-content/themes/generatepress/assets/css/all.min.css?ver=3.0.2' media='all' />
<style id='generate-style-inline-css'>
@media (max-width:768px){}
.generate-columns {margin-bottom: 20px;padding-left: 20px;}.generate-columns-container {margin-left: -20px;}.page-header {margin-bottom: 20px;margin-left: 20px}.generate-columns-container > .paging-navigation {margin-left: 20px;}
body{background-color:#ffffff;color:#3a3a3a;}a{color:#ed4250;}a:hover, a:focus, a:active{color:#ed0013;}body .grid-container{max-width:1140px;}.wp-block-group__inner-container{max-width:1140px;margin-left:auto;margin-right:auto;}.site-header .header-image{width:200px;}.generate-back-to-top{font-size:20px;border-radius:3px;position:fixed;bottom:30px;right:30px;line-height:40px;width:40px;text-align:center;z-index:10;transition:opacity 300ms ease-in-out;}.navigation-search{position:absolute;left:-99999px;pointer-events:none;visibility:hidden;z-index:20;width:100%;top:0;transition:opacity 100ms ease-in-out;opacity:0;}.navigation-search.nav-search-active{left:0;right:0;pointer-events:auto;visibility:visible;opacity:1;}.navigation-search input[type="search"]{outline:0;border:0;vertical-align:bottom;line-height:1;opacity:0.9;width:100%;z-index:20;border-radius:0;-webkit-appearance:none;height:60px;}.navigation-search input::-ms-clear{display:none;width:0;height:0;}.navigation-search input::-ms-reveal{display:none;width:0;height:0;}.navigation-search input::-webkit-search-decoration, .navigation-search input::-webkit-search-cancel-button, .navigation-search input::-webkit-search-results-button, .navigation-search input::-webkit-search-results-decoration{display:none;}.main-navigation li.search-item{z-index:21;}li.search-item.active{transition:opacity 100ms ease-in-out;}.nav-left-sidebar .main-navigation li.search-item.active,.nav-right-sidebar .main-navigation li.search-item.active{width:auto;display:inline-block;float:right;}.gen-sidebar-nav .navigation-search{top:auto;bottom:0;}body, button, input, select, textarea{font-family:"Pontano Sans", sans-serif;font-weight:500;font-size:19px;}body{line-height:1.8;}.entry-content > [class*="wp-block-"]:not(:last-child){margin-bottom:1.5em;}.main-title{text-transform:uppercase;font-size:40px;}.site-description{font-size:16px;}.main-navigation a, .menu-toggle{font-weight:700;}.main-navigation .main-nav ul ul li a{font-size:14px;}.widget-title{font-weight:600;font-size:19px;}.sidebar .widget, .footer-widgets .widget{font-size:17px;}button:not(.menu-toggle),html input[type="button"],input[type="reset"],input[type="submit"],.button,.wp-block-button .wp-block-button__link{text-transform:uppercase;font-size:14px;}h1{font-weight:bold;}h2{font-weight:bold;font-size:30px;}h3{font-weight:bold;font-size:22px;}h4{font-size:inherit;}h5{font-size:inherit;}@media (max-width:768px){.main-title{font-size:30px;}h1{font-size:30px;}h2{font-size:25px;}}.top-bar{background-color:#636363;color:#ffffff;}.top-bar a{color:#ffffff;}.top-bar a:hover{color:#303030;}.site-header{background-color:#15a974;color:#3a3a3a;}.site-header a{color:#3a3a3a;}.main-title a,.main-title a:hover{color:#222222;}.site-description{color:#757575;}.main-navigation,.main-navigation ul ul{background-color:#16aa74;}.main-navigation .main-nav ul li a,.menu-toggle, .main-navigation .menu-bar-items{color:#ffffff;}.main-navigation .main-nav ul li:hover > a,.main-navigation .main-nav ul li:focus > a, .main-navigation .main-nav ul li.sfHover > a, .main-navigation .menu-bar-item:hover > a, .main-navigation .menu-bar-item.sfHover > a{color:#ffffff;background-color:#119b6d;}button.menu-toggle:hover,button.menu-toggle:focus,.main-navigation .mobile-bar-items a,.main-navigation .mobile-bar-items a:hover,.main-navigation .mobile-bar-items a:focus{color:#ffffff;}.main-navigation .main-nav ul li[class*="current-menu-"] > a{background-color:#119b6d;}.main-navigation .main-nav ul li[class*="current-menu-"] > a:hover,.main-navigation .main-nav ul li[class*="current-menu-"].sfHover > a{background-color:#119b6d;}.navigation-search input[type="search"],.navigation-search input[type="search"]:active, .navigation-search input[type="search"]:focus, .main-navigation .main-nav ul li.search-item.active > a, .main-navigation .menu-bar-items .search-item.active > a{color:#ffffff;background-color:#119b6d;}.main-navigation ul ul{background-color:#16aa74;}.main-navigation .main-nav ul ul li a{color:#ffffff;}.main-navigation .main-nav ul ul li:hover > a,.main-navigation .main-nav ul ul li:focus > a,.main-navigation .main-nav ul ul li.sfHover > a{color:#c2e8de;background-color:#119b6d;}.main-navigation .main-nav ul ul li[class*="current-menu-"] > a{background-color:#119b6d;}.main-navigation .main-nav ul ul li[class*="current-menu-"] > a:hover,.main-navigation .main-nav ul ul li[class*="current-menu-"].sfHover > a{background-color:#119b6d;}.entry-title a{color:#3a3a3a;}.entry-title a:hover{color:#ed4250;}.entry-meta{color:#595959;}.entry-meta a{color:#595959;}.entry-meta a:hover{color:#ed4250;}.sidebar .widget{background-color:#fafafa;}.sidebar .widget .widget-title{color:#3a3a3a;}.footer-widgets{color:#ffffff;background-color:#0d6546;}.footer-widgets a{color:#ffffff;}.footer-widgets a:hover{color:#ffffff;}.footer-widgets .widget-title{color:#ffffff;}.site-info{color:#ffffff;background-color:#0b553a;}.site-info a{color:#ffffff;}.site-info a:hover{color:#939393;}.footer-bar .widget_nav_menu .current-menu-item a{color:#939393;}input[type="text"],input[type="email"],input[type="url"],input[type="password"],input[type="search"],input[type="tel"],input[type="number"],textarea,select{color:#0a0a0a;background-color:#fafafa;border-color:#e8e8e8;}input[type="text"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="search"]:focus,input[type="tel"]:focus,input[type="number"]:focus,textarea:focus,select:focus{color:#666666;background-color:#ffffff;border-color:#bfbfbf;}button,html input[type="button"],input[type="reset"],input[type="submit"],a.button,a.wp-block-button__link:not(.has-background){color:#ffffff;background-color:#ed4250;}button:hover,html input[type="button"]:hover,input[type="reset"]:hover,input[type="submit"]:hover,a.button:hover,button:focus,html input[type="button"]:focus,input[type="reset"]:focus,input[type="submit"]:focus,a.button:focus,a.wp-block-button__link:not(.has-background):active,a.wp-block-button__link:not(.has-background):focus,a.wp-block-button__link:not(.has-background):hover{color:#ffffff;background-color:#ed0013;}a.generate-back-to-top{background-color:rgba( 0,0,0,0.4 );color:#ffffff;}a.generate-back-to-top:hover,a.generate-back-to-top:focus{background-color:rgba( 0,0,0,0.6 );color:#ffffff;}@media (max-width: 768px){.main-navigation .menu-bar-item:hover > a, .main-navigation .menu-bar-item.sfHover > a{background:none;color:#ffffff;}}.inside-top-bar{padding:10px;}.inside-header{padding:20px 40px 15px 40px;}.separate-containers .inside-article, .separate-containers .comments-area, .separate-containers .page-header, .separate-containers .paging-navigation, .one-container .site-content, .inside-page-header, .wp-block-group__inner-container{padding:60px 35px 60px 35px;}.entry-content .alignwide, body:not(.no-sidebar) .entry-content .alignfull{margin-left:-35px;width:calc(100% + 70px);max-width:calc(100% + 70px);}.one-container.right-sidebar .site-main,.one-container.both-right .site-main{margin-right:35px;}.one-container.left-sidebar .site-main,.one-container.both-left .site-main{margin-left:35px;}.one-container.both-sidebars .site-main{margin:0px 35px 0px 35px;}.main-navigation .main-nav ul li a,.menu-toggle,.main-navigation .mobile-bar-items a{line-height:40px;}.navigation-search input[type="search"]{height:40px;}.rtl .menu-item-has-children .dropdown-menu-toggle{padding-left:20px;}.rtl .main-navigation .main-nav ul li.menu-item-has-children > a{padding-right:20px;}.widget-area .widget{padding:60px 30px 20px 30px;}.footer-widgets{padding:60px;}.site-info{padding:20px;}@media (max-width:768px){.separate-containers .inside-article, .separate-containers .comments-area, .separate-containers .page-header, .separate-containers .paging-navigation, .one-container .site-content, .inside-page-header, .wp-block-group__inner-container{padding:30px;}.site-info{padding-right:10px;padding-left:10px;}.entry-content .alignwide, body:not(.no-sidebar) .entry-content .alignfull{margin-left:-30px;width:calc(100% + 60px);max-width:calc(100% + 60px);}}/* End cached CSS */@media (max-width: 768px){.main-navigation .menu-toggle,.main-navigation .mobile-bar-items,.sidebar-nav-mobile:not(#sticky-placeholder){display:block;}.main-navigation ul,.gen-sidebar-nav{display:none;}[class*="nav-float-"] .site-header .inside-header > *{float:none;clear:both;}}
.main-navigation .navigation-logo img {height:40px;}@media (max-width: 1150px) {.main-navigation .navigation-logo.site-logo {margin-left:0;}body.sticky-menu-logo.nav-float-left .main-navigation .site-logo.navigation-logo {margin-right:0;}}
</style>
<link rel='stylesheet' id='generate-blog-css'  href='https://designseer.com/wp-content/plugins/gp-premium/blog/functions/css/style.min.css?ver=1.12.3' media='all' />
<link rel='stylesheet' id='generate-menu-logo-css'  href='https://designseer.com/wp-content/plugins/gp-premium/menu-plus/functions/css/menu-logo.min.css?ver=1.12.3' media='all' />
<style id='generate-menu-logo-inline-css'>
@media (max-width: 768px){.sticky-menu-logo .navigation-stick:not(.mobile-header-navigation) .menu-toggle,.menu-logo .main-navigation:not(.mobile-header-navigation) .menu-toggle{display:inline-block;clear:none;width:auto;float:right;}.sticky-menu-logo .navigation-stick:not(.mobile-header-navigation) .mobile-bar-items,.menu-logo .main-navigation:not(.mobile-header-navigation) .mobile-bar-items{position:relative;float:right;}.regular-menu-logo .main-navigation:not(.navigation-stick):not(.mobile-header-navigation) .menu-toggle{display:inline-block;clear:none;width:auto;float:right;}.regular-menu-logo .main-navigation:not(.navigation-stick):not(.mobile-header-navigation) .mobile-bar-items{position:relative;float:right;}body[class*="nav-float-"].menu-logo-enabled:not(.sticky-menu-logo) .main-navigation .main-nav{display:block;}.sticky-menu-logo.nav-float-left .navigation-stick:not(.mobile-header-navigation) .menu-toggle,.menu-logo.nav-float-left .main-navigation:not(.mobile-header-navigation) .menu-toggle,.regular-menu-logo.nav-float-left .main-navigation:not(.navigation-stick):not(.mobile-header-navigation) .menu-toggle{float:left;}}
</style>
<script src='https://designseer.com/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script src='https://designseer.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<link rel="https://api.w.org/" href="https://designseer.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://designseer.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://designseer.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.6.2" />
<meta name="viewport" content="width=device-width, initial-scale=1"><!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-126826447-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-126826447-1');
</script>
<link rel="icon" href="https://designseer.com/wp-content/uploads/2018/10/favnew.png" sizes="32x32" />
<link rel="icon" href="https://designseer.com/wp-content/uploads/2018/10/favnew.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://designseer.com/wp-content/uploads/2018/10/favnew.png" />
<meta name="msapplication-TileImage" content="https://designseer.com/wp-content/uploads/2018/10/favnew.png" />
		<style id="wp-custom-css">
			body .wp-caption .wp-caption-text {
	font-size: 14px;
	font-weight: bold;
	letter-spacing: 2px;
	text-align: center;
}

.wp-caption img[class*=wp-image-] {
	-webkit-box-shadow: -4px 23px 21px -13px rgba(226, 244, 238, 1);
	-moz-box-shadow: -4px 23px 21px -13px rgba(226, 244, 238, 1);
	box-shadow: -4px 23px 21px -13px rgba(226, 244, 238, 1);
}

.single article h3,
.single article h2 {
	margin-top: 60px;
}

.single article big {
	padding: 6px 10px;
	background: #f2f5f7;
	color: #fff;
	background-color: #21D4FD;
	background-image: linear-gradient(135deg, #21D4FD 0%, #3d51d8 100%);
	border-radius: 4px;
}

.single article h2 {
	background-image: linear-gradient(120deg, #84fab0 0%, #8fd3f4 100%);
	background-repeat: no-repeat;
	background-size: 100% 0.2em;
	background-position: 0 98%;
	transition: background-size 0.25s ease-in;
	line-height: 1.5;
}

.single article h2:hover {
	background-size: 100% 88%;
}

.widget_recent_entries a {
	font-size: 14px;
	font-weight: 600;
	line-height: 0.8px !important;
	color: #3a3a3a;
}

.widget_recent_entries a:hover {
	color: #ed4250;
}

.widget ul li {
	padding: 5px;
	margin-bottom: 5px;
	line-height: 20px;
}

.page-header {
	background-color: #e2f4ee !important;
	text-align: center;
	box-sizing: border-box;
	font-weight: 600;
}

.page-header .taxonomy-description {
	max-width: 800px;
	margin: 0 auto;
}
nav.rank-math-breadcrumb {
    margin: 10px 5px -10px 8px;
    
    font-size: 14px;
    font-family: Arial;
}

}		</style>
		</head>

<body class="error404 wp-custom-logo wp-embed-responsive post-image-below-header post-image-aligned-center generate-columns-activated sticky-menu-fade sticky-menu-logo menu-logo-enabled no-sidebar nav-float-right separate-containers fluid-header active-footer-widgets-3 nav-search-enabled header-aligned-left dropdown-hover" itemtype="https://schema.org/WebPage" itemscope>
	<a class="screen-reader-text skip-link" href="#content" title="Skip to content">Skip to content</a>		<header id="masthead" class="site-header" itemtype="https://schema.org/WPHeader" itemscope>
			<div class="inside-header grid-container grid-parent">
				<div class="site-logo">
					<a href="https://designseer.com/" title="DesignSeer" rel="home">
						<img  class="header-image is-logo-image" alt="DesignSeer" src="https://designseer.com/wp-content/uploads/logo-new.png" title="DesignSeer" />
					</a>
				</div>		<nav id="site-navigation" class="main-navigation sub-menu-right" itemtype="https://schema.org/SiteNavigationElement" itemscope>
			<div class="inside-navigation">
				<div class="site-logo sticky-logo navigation-logo">
					<a href="https://designseer.com/" title="DesignSeer" rel="home">
						<img src="https://designseer.com/wp-content/uploads/logo-new.png" alt="DesignSeer" class="is-logo-image" />
					</a>
				</div><form method="get" class="search-form navigation-search" action="https://designseer.com/">
					<input type="search" class="search-field" value="" name="s" title="Search" />
				</form>		<div class="mobile-bar-items">
						<span class="search-item">
				<a aria-label="Open Search Bar" href="#">
					<span class="gp-icon icon-search"><svg viewBox="0 0 512 512" aria-hidden="true" role="img" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1em" height="1em">
						<path fill-rule="evenodd" clip-rule="evenodd" d="M208 48c-88.366 0-160 71.634-160 160s71.634 160 160 160 160-71.634 160-160S296.366 48 208 48zM0 208C0 93.125 93.125 0 208 0s208 93.125 208 208c0 48.741-16.765 93.566-44.843 129.024l133.826 134.018c9.366 9.379 9.355 24.575-.025 33.941-9.379 9.366-24.575 9.355-33.941-.025L337.238 370.987C301.747 399.167 256.839 416 208 416 93.125 416 0 322.875 0 208z"/>
					</svg><svg viewBox="0 0 512 512" aria-hidden="true" role="img" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1em" height="1em">
						<path d="M71.029 71.029c9.373-9.372 24.569-9.372 33.942 0L256 222.059l151.029-151.03c9.373-9.372 24.569-9.372 33.942 0 9.372 9.373 9.372 24.569 0 33.942L289.941 256l151.03 151.029c9.372 9.373 9.372 24.569 0 33.942-9.373 9.372-24.569 9.372-33.942 0L256 289.941l-151.029 151.03c-9.373 9.372-24.569 9.372-33.942 0-9.372-9.373-9.372-24.569 0-33.942L222.059 256 71.029 104.971c-9.372-9.373-9.372-24.569 0-33.942z" />
					</svg></span>				</a>
			</span>
		</div>
						<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
					<span class="gp-icon icon-menu-bars"><svg viewBox="0 0 512 512" aria-hidden="true" role="img" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1em" height="1em">
						<path d="M0 96c0-13.255 10.745-24 24-24h464c13.255 0 24 10.745 24 24s-10.745 24-24 24H24c-13.255 0-24-10.745-24-24zm0 160c0-13.255 10.745-24 24-24h464c13.255 0 24 10.745 24 24s-10.745 24-24 24H24c-13.255 0-24-10.745-24-24zm0 160c0-13.255 10.745-24 24-24h464c13.255 0 24 10.745 24 24s-10.745 24-24 24H24c-13.255 0-24-10.745-24-24z" />
					</svg><svg viewBox="0 0 512 512" aria-hidden="true" role="img" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1em" height="1em">
						<path d="M71.029 71.029c9.373-9.372 24.569-9.372 33.942 0L256 222.059l151.029-151.03c9.373-9.372 24.569-9.372 33.942 0 9.372 9.373 9.372 24.569 0 33.942L289.941 256l151.03 151.029c9.372 9.373 9.372 24.569 0 33.942-9.373 9.372-24.569 9.372-33.942 0L256 289.941l-151.029 151.03c-9.373 9.372-24.569 9.372-33.942 0-9.372-9.373-9.372-24.569 0-33.942L222.059 256 71.029 104.971c-9.372-9.373-9.372-24.569 0-33.942z" />
					</svg></span><span class="mobile-menu">Menu</span>				</button>
				<div id="primary-menu" class="main-nav"><ul id="menu-fullmenu" class=" menu sf-menu"><li id="menu-item-11016" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-11016"><a href="https://designseer.com/">Home</a></li>
<li id="menu-item-21682" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-21682"><a href="https://designseer.com/category/graphics/">Graphic Freebies<span role="presentation" class="dropdown-menu-toggle"><span class="gp-icon icon-arrow"><svg viewBox="0 0 330 512" aria-hidden="true" role="img" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1em" height="1em">
						<path d="M305.913 197.085c0 2.266-1.133 4.815-2.833 6.514L171.087 335.593c-1.7 1.7-4.249 2.832-6.515 2.832s-4.815-1.133-6.515-2.832L26.064 203.599c-1.7-1.7-2.832-4.248-2.832-6.514s1.132-4.816 2.832-6.515l14.162-14.163c1.7-1.699 3.966-2.832 6.515-2.832 2.266 0 4.815 1.133 6.515 2.832l111.316 111.317 111.316-111.317c1.7-1.699 4.249-2.832 6.515-2.832s4.815 1.133 6.515 2.832l14.162 14.163c1.7 1.7 2.833 4.249 2.833 6.515z" fill-rule="nonzero"/>
					</svg></span></span></a>
<ul class="sub-menu">
	<li id="menu-item-21921" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-21921"><a href="https://designseer.com/tag/business-card/">Business Card</a></li>
	<li id="menu-item-21919" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-21919"><a href="https://designseer.com/tag/brushes/">Brushes</a></li>
	<li id="menu-item-21920" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-21920"><a href="https://designseer.com/tag/flyer/">Flyer</a></li>
	<li id="menu-item-21923" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-21923"><a href="https://designseer.com/tag/fonts/">Fonts</a></li>
	<li id="menu-item-21918" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-21918"><a href="https://designseer.com/tag/mockup/">Mockup</a></li>
	<li id="menu-item-21922" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-21922"><a href="https://designseer.com/tag/website-psd/">Website PSD</a></li>
	<li id="menu-item-21926" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-21926"><a># More<span role="presentation" class="dropdown-menu-toggle"><span class="gp-icon icon-arrow-right"><svg viewBox="0 0 192 512" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="1.414">
						<path d="M178.425 256.001c0 2.266-1.133 4.815-2.832 6.515L43.599 394.509c-1.7 1.7-4.248 2.833-6.514 2.833s-4.816-1.133-6.515-2.833l-14.163-14.162c-1.699-1.7-2.832-3.966-2.832-6.515 0-2.266 1.133-4.815 2.832-6.515l111.317-111.316L16.407 144.685c-1.699-1.7-2.832-4.249-2.832-6.515s1.133-4.815 2.832-6.515l14.163-14.162c1.7-1.7 4.249-2.833 6.515-2.833s4.815 1.133 6.514 2.833l131.994 131.993c1.7 1.7 2.832 4.249 2.832 6.515z" fill-rule="nonzero"/>
					</svg></span></span></a>
	<ul class="sub-menu">
		<li id="menu-item-21924" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21924"><a href="https://designseer.com/category/graphics/psd/">Free PSD</a></li>
		<li id="menu-item-21925" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21925"><a href="https://designseer.com/category/graphics/tutorials/">Tutorials</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-21676" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-21676"><a href="#">For Web Designers<span role="presentation" class="dropdown-menu-toggle"><span class="gp-icon icon-arrow"><svg viewBox="0 0 330 512" aria-hidden="true" role="img" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1em" height="1em">
						<path d="M305.913 197.085c0 2.266-1.133 4.815-2.833 6.514L171.087 335.593c-1.7 1.7-4.249 2.832-6.515 2.832s-4.815-1.133-6.515-2.832L26.064 203.599c-1.7-1.7-2.832-4.248-2.832-6.514s1.132-4.816 2.832-6.515l14.162-14.163c1.7-1.699 3.966-2.832 6.515-2.832 2.266 0 4.815 1.133 6.515 2.832l111.316 111.317 111.316-111.317c1.7-1.699 4.249-2.832 6.515-2.832s4.815 1.133 6.515 2.832l14.162 14.163c1.7 1.7 2.833 4.249 2.833 6.515z" fill-rule="nonzero"/>
					</svg></span></span></a>
<ul class="sub-menu">
	<li id="menu-item-21677" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21677"><a href="https://designseer.com/category/coding/">Code Snippets</a></li>
	<li id="menu-item-21797" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21797"><a href="https://designseer.com/category/cms-templates/">CMS Templates</a></li>
	<li id="menu-item-21681" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21681"><a href="https://designseer.com/category/wordpress-themes/">WordPress Themes</a></li>
	<li id="menu-item-21680" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21680"><a href="https://designseer.com/category/wordpress-plugins/">WordPress Plugins</a></li>
	<li id="menu-item-21679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21679"><a href="https://designseer.com/category/website-templates/">Website Templates</a></li>
	<li id="menu-item-21678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21678"><a href="https://designseer.com/category/inspiration/">Web Design Inspiration</a></li>
</ul>
</li>
<li class="search-item menu-item-align-right"><a aria-label="Open Search Bar" href="#"><span class="gp-icon icon-search"><svg viewBox="0 0 512 512" aria-hidden="true" role="img" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1em" height="1em">
						<path fill-rule="evenodd" clip-rule="evenodd" d="M208 48c-88.366 0-160 71.634-160 160s71.634 160 160 160 160-71.634 160-160S296.366 48 208 48zM0 208C0 93.125 93.125 0 208 0s208 93.125 208 208c0 48.741-16.765 93.566-44.843 129.024l133.826 134.018c9.366 9.379 9.355 24.575-.025 33.941-9.379 9.366-24.575 9.355-33.941-.025L337.238 370.987C301.747 399.167 256.839 416 208 416 93.125 416 0 322.875 0 208z"/>
					</svg><svg viewBox="0 0 512 512" aria-hidden="true" role="img" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1em" height="1em">
						<path d="M71.029 71.029c9.373-9.372 24.569-9.372 33.942 0L256 222.059l151.029-151.03c9.373-9.372 24.569-9.372 33.942 0 9.372 9.373 9.372 24.569 0 33.942L289.941 256l151.03 151.029c9.372 9.373 9.372 24.569 0 33.942-9.373 9.372-24.569 9.372-33.942 0L256 289.941l-151.029 151.03c-9.373 9.372-24.569 9.372-33.942 0-9.372-9.373-9.372-24.569 0-33.942L222.059 256 71.029 104.971c-9.372-9.373-9.372-24.569 0-33.942z" />
					</svg></span></a></li></ul></div>			</div>
		</nav>
					</div>
		</header>
		
	<div id="page" class="site grid-container container hfeed grid-parent">
				<div id="content" class="site-content">
			
	<div id="primary" class="content-area grid-parent mobile-grid-100 grid-100 tablet-grid-100">
		<main id="main" class="site-main">
			<div class="generate-columns-container "><div class="inside-article">

	
	<header class="entry-header">
				<h1 class="entry-title" itemprop="headline">Oops! That page can&rsquo;t be found.</h1>
	</header>

	
	<div class="entry-content" itemprop="text">
		<p>It looks like nothing was found at this location. Maybe try searching?</p><form method="get" class="search-form" action="https://designseer.com/">
	<label>
		<span class="screen-reader-text">Search for:</span>
		<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" title="Search for:">
	</label>
	<input type="submit" class="search-submit" value="Search"></form>
	</div>

	
</div>
</div><!-- .generate-columns-contaier --><div style="margin-left:10px;">
	<!-- Header - set 2 -->
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-4397412252424400"
     data-ad-slot="3856149235"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>			</main>
	</div>

	<!--WPFC_FOOTER_START-->
	</div>
</div>


<div class="site-footer">
				<div id="footer-widgets" class="site footer-widgets">
				<div class="footer-widgets-container grid-container grid-parent">
					<div class="inside-footer-widgets">
							<div class="footer-widget-1 grid-parent grid-33 tablet-grid-50 mobile-grid-100">
		<aside id="text-6" class="widget inner-padding widget_text"><h2 class="widget-title">About</h2>			<div class="textwidget"><p><img loading="lazy" class="size-full wp-image-21930 alignleft" src="https://designseer.com/wp-content/uploads/designseer-min.png" alt="" width="64" height="64" /> Unbiased reviews just for you. There is a flood of biased reviews where business review themselves &#8211; theme companies compare their themes, software companies review their products. We like to think different and real.</p>
</div>
		</aside>	</div>
		<div class="footer-widget-2 grid-parent grid-33 tablet-grid-50 mobile-grid-100">
		<aside id="pages-3" class="widget inner-padding widget_pages"><h2 class="widget-title">Useful Links</h2>
			<ul>
				<li class="page_item page-item-18423"><a href="https://designseer.com/about/">About</a></li>
<li class="page_item page-item-22323"><a href="https://designseer.com/affiliate-disclosure/">Affiliate Disclosure</a></li>
<li class="page_item page-item-18129"><a href="https://designseer.com/contact/">Contact Me</a></li>
<li class="page_item page-item-18930"><a href="https://designseer.com/privacy-policy/">Privacy Policy</a></li>
<li class="page_item page-item-12711"><a href="https://designseer.com/terms/">Terms of Service</a></li>
			</ul>

			</aside>	</div>
		<div class="footer-widget-3 grid-parent grid-33 tablet-grid-50 mobile-grid-100">
		<aside id="categories-2" class="widget inner-padding widget_categories"><h2 class="widget-title">Blog categories</h2>
			<ul>
					<li class="cat-item cat-item-262"><a href="https://designseer.com/category/cms-templates/">CMS Templates</a> (6)
</li>
	<li class="cat-item cat-item-209"><a href="https://designseer.com/category/coding/" title="Everything related to jquery, css3, html5 goes here. Get snippets for your website for free.">Code Snippets</a> (18)
</li>
	<li class="cat-item cat-item-20"><a href="https://designseer.com/category/graphics/psd/" title="Photoshop free psd files for icons, ui kits, website templates with over 1000 sets to choose from.">Free PSD Templates</a> (19)
</li>
	<li class="cat-item cat-item-3"><a href="https://designseer.com/category/graphics/" title="In this category, you get to download free templates for designing business cards, flyers, mockups, brushes, logos and more. These handpicked freebies help you design custom websites, custom graphics elements and more.



Brushes



Business Card




Flyer





Fonts


Icons


Mockup





Textures


Website PSD











">Graphic Freebies</a> (26)
</li>
	<li class="cat-item cat-item-234"><a href="https://designseer.com/category/guides/">Guides</a> (1)
</li>
	<li class="cat-item cat-item-163"><a href="https://designseer.com/category/graphics/tutorials/">Tutorials</a> (5)
</li>
	<li class="cat-item cat-item-1"><a href="https://designseer.com/category/inspiration/" title="Daily updates for fresh websites that are successful and generate revenue. Also are handpciked selection of award-winning websites that create new trends.">Web Design Inspiration</a> (14)
</li>
	<li class="cat-item cat-item-64"><a href="https://designseer.com/category/website-templates/" title="Create a new website for business, portfolio, blog/magazine, real estate, food and much more with our exclusive free website templates and awesome collection of fresh designs. HTML5 &amp; CSS3 has gained high popularity and you may be actually searching one template as you have visited our site.">Website Templates</a> (24)
</li>
	<li class="cat-item cat-item-15"><a href="https://designseer.com/category/wordpress-plugins/" title="Plugins which fuel the WordPress system whether its advanced gallery sliders or the essential SEO plguins.">WordPress Plugins</a> (19)
</li>
	<li class="cat-item cat-item-8"><a href="https://designseer.com/category/wordpress-themes/" title="We review amazing free and premium WordPress themes suitable for your business. Either its blogging, news, creative portfolio, travel, fashion - we review them all. 
">WordPress Themes</a> (46)
</li>
			</ul>

			</aside>	</div>
						</div>
				</div>
			</div>
					<footer class="site-info" itemtype="https://schema.org/WPFooter" itemscope>
			<div class="inside-site-info grid-container grid-parent">
								<div class="copyright-bar">
					© 2021 DesignSeer . All Rights Reserved.				</div>
			</div>
		</footer>
		</div>

<a title="Scroll back to top" aria-label="Scroll back to top" rel="nofollow" href="#" class="generate-back-to-top" style="opacity:0;visibility:hidden;" data-scroll-speed="400" data-start-scroll="300">
					<span class="gp-icon icon-arrow-up"><svg viewBox="0 0 330 512" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="1.414">
						<path d="M305.863 314.916c0 2.266-1.133 4.815-2.832 6.514l-14.157 14.163c-1.699 1.7-3.964 2.832-6.513 2.832-2.265 0-4.813-1.133-6.512-2.832L164.572 224.276 53.295 335.593c-1.699 1.7-4.247 2.832-6.512 2.832-2.265 0-4.814-1.133-6.513-2.832L26.113 321.43c-1.699-1.7-2.831-4.248-2.831-6.514s1.132-4.816 2.831-6.515L158.06 176.408c1.699-1.7 4.247-2.833 6.512-2.833 2.265 0 4.814 1.133 6.513 2.833L303.03 308.4c1.7 1.7 2.832 4.249 2.832 6.515z" fill-rule="nonzero"/>
					</svg></span>
				</a><script id='generate-smooth-scroll-js-extra'>
var smooth = {"elements":[".smooth-scroll","li.smooth-scroll a"],"duration":"800"};
</script>
<script src='https://designseer.com/wp-content/plugins/gp-premium/general/js/smooth-scroll.min.js?ver=1.12.3' id='generate-smooth-scroll-js'></script>
<!--[if lte IE 11]>
<script src='https://designseer.com/wp-content/themes/generatepress/assets/js/classList.min.js?ver=3.0.2' id='generate-classlist-js'></script>
<![endif]-->
<script id='generate-main-js-extra'>
var generatepressMenu = {"toggleOpenedSubMenus":"1","openSubMenuLabel":"Open Sub-Menu","closeSubMenuLabel":"Close Sub-Menu"};
</script>
<script src='https://designseer.com/wp-content/themes/generatepress/assets/js/main.min.js?ver=3.0.2' id='generate-main-js'></script>
<script id='generate-navigation-search-js-extra'>
var generatepressNavSearch = {"open":"Open Search Bar","close":"Close Search Bar"};
</script>
<script src='https://designseer.com/wp-content/themes/generatepress/assets/js/navigation-search.min.js?ver=3.0.2' id='generate-navigation-search-js'></script>
<script src='https://designseer.com/wp-content/themes/generatepress/assets/js/back-to-top.min.js?ver=3.0.2' id='generate-back-to-top-js'></script>
<script id='q2w3_fixed_widget-js-extra'>
var q2w3_sidebar_options = [{"sidebar":"bsf-sb-free-wp-themes","margin_top":10,"margin_bottom":0,"stop_id":"fstop","screen_max_width":0,"screen_max_height":0,"width_inherit":false,"refresh_interval":1500,"window_load_hook":false,"disable_mo_api":false,"widgets":["text-3"]},{"sidebar":"bsf-sb-blogger-templates","margin_top":10,"margin_bottom":0,"stop_id":"fstop","screen_max_width":0,"screen_max_height":0,"width_inherit":false,"refresh_interval":1500,"window_load_hook":false,"disable_mo_api":false,"widgets":["text-2"]},{"sidebar":"bsf-sb-flyer-size","margin_top":10,"margin_bottom":0,"stop_id":"fstop","screen_max_width":0,"screen_max_height":0,"width_inherit":false,"refresh_interval":1500,"window_load_hook":false,"disable_mo_api":false,"widgets":["custom_html-5"]},{"sidebar":"bsf-sb-business-card-mockups","margin_top":10,"margin_bottom":0,"stop_id":"fstop","screen_max_width":0,"screen_max_height":0,"width_inherit":false,"refresh_interval":1500,"window_load_hook":false,"disable_mo_api":false,"widgets":["text-4"]}];
</script>
<script src='https://designseer.com/wp-content/plugins/q2w3-fixed-widget/js/q2w3-fixed-widget.min.js?ver=5.2.0' id='q2w3_fixed_widget-js'></script>
<script src='https://designseer.com/wp-includes/js/wp-embed.min.js?ver=5.6.2' id='wp-embed-js'></script>

</body>
</html>
